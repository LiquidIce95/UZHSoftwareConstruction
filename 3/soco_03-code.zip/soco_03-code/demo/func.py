def add_one(n):
    return n + 1

def add_two(n):
    return n + 2

def main():
    print("Hello, how are you?")

if __name__ == "__main__":
    main()
