import demo.func

print(demo.func.add_one(2))