import pprint
var1 = 123

def my_sum(a,b):
    return a + b

pprint.pprint(globals())